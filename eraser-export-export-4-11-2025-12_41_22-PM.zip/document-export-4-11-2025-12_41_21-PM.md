# 

```
+-------------------+
|   Data Source     |
| (Yahoo Finance)   |
+-------------------+
          |
          v
+-------------------+
|  Data Loading     |
| (Pandas CSV Read) |
+-------------------+
          |
          v
+-------------------+
| Data Preprocessing|
| - Date Conversion |
| - Indexing        |
| - Windowing       |
+-------------------+
          |
          v
+-------------------+
|   LSTM Model      |
| - Input Layer     |
| - LSTM Layer      |
| - Dense Layers    |
| - Output Layer    |
+-------------------+
          |
          v
+-------------------+
| Model Training    |
| - Training Data   |
| - Validation Data |
+-------------------+
          |
          v
+-------------------+
|   Model Testing   |
| - Test Data       |
| - Recursive Pred. |
+-------------------+
          |
          v
+-------------------+
|   Visualization   |
| - Training Pred.  |
| - Validation Pred.|
| - Testing Pred.   |
| - Recursive Pred. |
+-------------------+
```


